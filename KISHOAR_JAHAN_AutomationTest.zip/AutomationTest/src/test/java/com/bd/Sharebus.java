package com.bd;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class Sharebus extends BaseDriver {

	public String baseUrl = "https://test.sharebus.co/";

	@BeforeSuite
	public void visitURL() throws InterruptedException {
		driver.get(baseUrl);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		Thread.sleep(8000);
	}

	@Test
	public void login() throws InterruptedException {

		WebElement signIn = driver.findElement(By.xpath("//*[@id=\"app\"]/nav/div/ul/li/button"));
		signIn.click();
		Thread.sleep(3000);

		WebElement email = driver.findElement(By.id("email"));
		WebElement password = driver.findElement(By.id("password"));
		email.sendKeys("brainstation23@yopmail.com");
		Thread.sleep(1000);
		password.sendKeys("Pass@1234");
		Thread.sleep(1000);
		WebElement login = driver
				.findElement(By.xpath("//body/div[@id='app']/div[1]/div[1]/div[1]/form[1]/div[4]/button[1]"));
		login.click();
		Thread.sleep(8000);
		System.out.println("Login Done with Click");

		WebElement dropDown = driver
				.findElement(By.xpath("//body/div[@id='app']/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/span[1]"));
		dropDown.click();

		WebElement ShareLead = driver.findElement(By.xpath("//body/div[3]/div[1]/ul[1]/li[2]/div[1]"));
		ShareLead.click();
		Thread.sleep(2000);
		WebElement ContinueBtn = driver
				.findElement(By.xpath("//body/div[@id='app']/div[1]/div[1]/div[1]/div[1]/button[1]"));
		ContinueBtn.click();
		Thread.sleep(10000);

//		Dynamic wait
//		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		WebElement Element = driver.findElement(By.xpath("//*[text()='Set up a Sharebus']"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView();", Element);
		Thread.sleep(2000);
		Element.click();
		Thread.sleep(5000);

		// Trip Details
		WebElement pageTop = driver.findElement(By.xpath("//body/div[@id='app']/div[1]/div[1]/div[1]"));
		WebElement footer = driver.findElement(By.xpath("//body/div[@id='app']/div[2]"));
		WebElement from = driver.findElement(By.id("startPoint"));

		WebElement to = driver.findElement(By.id("destination"));
		WebElement departureCalendar = driver.findElement(By.xpath(
				"//body/div[@id='app']/div[1]/div[1]/div[2]/div[1]/div[1]/form[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[1]/span[1]/input[1]"));
		WebElement departureTime = driver.findElement(By.xpath(
				"//body/div[@id='app']/div[1]/div[1]/div[2]/div[1]/div[1]/form[1]/div[1]/div[3]/div[1]/div[1]/div[1]/div[2]/span[1]/input[1]"));
		WebElement returnCalendar = driver.findElement(By.xpath(
				"//body/div[@id='app']/div[1]/div[1]/div[2]/div[1]/div[1]/form[1]/div[1]/div[3]/div[2]/div[1]/div[1]/div[1]/span[1]/input[1]"));
		WebElement returningTime = driver.findElement(By.xpath(
				"//body/div[@id='app']/div[1]/div[1]/div[2]/div[1]/div[1]/form[1]/div[1]/div[3]/div[2]/div[1]/div[1]/div[2]/span[1]/input[1]"));
		WebElement continueBtn = driver
				.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div[2]/div[1]/div/form/div[2]/button[2]"));

		from.click();
		from.sendKeys("Oslo Norway");
		Thread.sleep(1000);

		from.sendKeys(Keys.DOWN);
		Thread.sleep(2000);
		from.sendKeys(Keys.ENTER);
		Thread.sleep(5000);
		JavascriptExecutor Js = (JavascriptExecutor) driver;
		Js.executeScript("arguments[0].scrollIntoView();", from);
		Thread.sleep(1000);
		to.click();
		to.sendKeys("Kolbotn Norway");
		Thread.sleep(2000);

		to.sendKeys(Keys.DOWN);
		Thread.sleep(1000);
		to.sendKeys(Keys.ENTER);
		Thread.sleep(5000);

		// click on body
//		driver.findElement(By.xpath("//body/div[@id='app']/nav[1]/div[1]")).click();

		// Departure Date and Time selection
		departureCalendar.click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//body/div[3]/div[1]/div[1]/div[1]/button[2]/span[1]")).click();
		driver.findElement(By.xpath("//body/div[3]/div[1]/div[1]/div[1]/button[2]/span[1]")).click();
		driver.findElement(By.xpath("//tbody/tr[1]/td[7]")).click();
		Thread.sleep(2000);

		departureTime.click();
		String dTime = departureTime.getText();
		departureTime.sendKeys(dTime);
		Thread.sleep(2000);

		JavascriptExecutor scrollTo = (JavascriptExecutor) driver;
		scrollTo.executeScript("arguments[0].scrollIntoView();", to);
		Thread.sleep(1000);
		// Returning Date and Time selection
		returnCalendar.click();
		Thread.sleep(3000);

		driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div[1]/button[2]")).click();
		driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div[1]/button[2]")).click();
		driver.findElement(By.xpath("/html/body/div[3]/div[1]/div/div[2]/table/tbody/tr[3]/td[1]")).click();
		Thread.sleep(2000);

		returningTime.click();
		String rTime = returningTime.getText();
		returningTime.sendKeys(rTime);
		Thread.sleep(5000);
		// click on body
		driver.findElement(By.xpath("//body/div[@id='app']/nav[1]/div[1]")).click();

		JavascriptExecutor javaS = (JavascriptExecutor) driver;
		javaS.executeScript("arguments[0].scrollIntoView();", continueBtn);
		Thread.sleep(2000);
		continueBtn.click();
		Thread.sleep(15000);

//		Membership page

//		WebElement dropdown = driver
//				.findElement(By.xpath("//body/div[@id='app']/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[2]/ul[1]"));
		WebElement NTNUI = driver.findElement(By.xpath("//li[contains(text(),'NTNUI')]"));
// click Yes
		driver.findElement(By.xpath("//body/div[@id='app']/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/button[1]"))
				.click();
		Thread.sleep(1000);
//		click dropdown
//		driver.findElement(
//				By.xpath("//body/div[@id='app']/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/i[1]")).click();
//		Thread.sleep(1000);
		WebElement Search = driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div[2]/div[1]/div/div[1]/div[2]/div[1]/div/input"));
		Search.click();
		Search.sendKeys("NTNUI");
		driver.findElement(
				By.xpath("//body/div[@id='app']/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[1]/i[1]")).click();
		Thread.sleep(1000);

		driver.findElement(By.xpath("//body/div[@id='app']/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/button[2]")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div[2]/div[2]/div/div[2]/div[2]/div/button[2]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div[2]/div[2]/div/div[2]/div[3]/div/button[2]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[1]/div[2]/div[2]/div/div[2]/div[5]/button[2]")).click();
		Thread.sleep(5000);
//		click on publish 
		driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div[4]/button")).click();
		Thread.sleep(1000);
		
		


	}
}